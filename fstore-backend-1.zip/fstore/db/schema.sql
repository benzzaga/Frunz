-- fstore.am — схема базы данных
-- PostgreSQL 14+

CREATE EXTENSION IF NOT EXISTS "pgcrypto"; -- для gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;     -- регистронезависимые поля (email, username)

-- ==========================================================
-- ПОЛЬЗОВАТЕЛИ
-- ==========================================================
CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username            CITEXT UNIQUE NOT NULL,        -- публичный ник, а не имя/фамилия
    password_hash       TEXT NOT NULL,                 -- argon2id
    avatar_url          TEXT,
    bio                 TEXT,

    email               CITEXT UNIQUE,                 -- любой email-провайдер, не только gmail
    email_verified_at    TIMESTAMPTZ,

    phone_e164          TEXT UNIQUE,                    -- формат +374XXXXXXXX / +7XXXXXXXXXX и т.д.
    phone_country        TEXT,                          -- ISO2: AM, RU, KZ, BY, UZ, KG...
    phone_verified_at    TIMESTAMPTZ,

    -- рейтинг пересчитывается триггером ниже из таблицы reviews
    rating_avg          NUMERIC(3,2) NOT NULL DEFAULT 0,
    rating_count         INTEGER NOT NULL DEFAULT 0,
    deals_count          INTEGER NOT NULL DEFAULT 0,

    is_banned            BOOLEAN NOT NULL DEFAULT FALSE,
    ban_reason           TEXT,

    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Верифицированным считается профиль, где ПОДТВЕРЖДЁН телефон
-- (email — обязателен только перед оплатой конкретной сделки, см. purchase_intents)
CREATE VIEW users_verified AS
    SELECT * FROM users WHERE phone_verified_at IS NOT NULL;


-- ==========================================================
-- ВЕРИФИКАЦИЯ EMAIL (одноразовые коды)
-- ==========================================================
CREATE TABLE email_otp_codes (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email          CITEXT NOT NULL,
    code_hash      TEXT NOT NULL,          -- хэш кода, не сам код
    purpose        TEXT NOT NULL,          -- 'verify_email' | 'confirm_purchase'
    related_deal_id UUID,                  -- если код привязан к конкретной сделке
    attempts        INTEGER NOT NULL DEFAULT 0,
    max_attempts    INTEGER NOT NULL DEFAULT 5,
    expires_at      TIMESTAMPTZ NOT NULL,
    consumed_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_email_otp_user ON email_otp_codes(user_id, purpose);


-- ==========================================================
-- ВЕРИФИКАЦИЯ ТЕЛЕФОНА (SMS/звонок, СНГ)
-- ==========================================================
CREATE TABLE phone_otp_codes (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    phone_e164     TEXT NOT NULL,
    code_hash      TEXT NOT NULL,
    attempts        INTEGER NOT NULL DEFAULT 0,
    max_attempts    INTEGER NOT NULL DEFAULT 5,
    expires_at      TIMESTAMPTZ NOT NULL,
    consumed_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_phone_otp_user ON phone_otp_codes(user_id);


-- ==========================================================
-- КАТАЛОГ / ОБЪЯВЛЕНИЯ
-- ==========================================================
CREATE TABLE categories (
    id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug     TEXT UNIQUE NOT NULL,     -- 'game-accounts', 'subscriptions', 'keys'
    name_ru  TEXT NOT NULL,
    name_am  TEXT,
    name_en  TEXT
);

CREATE TABLE listings (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category_id    UUID NOT NULL REFERENCES categories(id),

    title          TEXT NOT NULL,
    description    TEXT NOT NULL,

    price_usd      NUMERIC(12,2) NOT NULL CHECK (price_usd > 0), -- канонический номинал сделки — USD
    stock          INTEGER NOT NULL DEFAULT 1,                    -- сколько единиц в наличии

    status         TEXT NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active','paused','removed','under_review')),

    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_listings_category ON listings(category_id, status);
CREATE INDEX idx_listings_seller   ON listings(seller_id);


-- ==========================================================
-- КОШЕЛЬКИ / ДЕПОЗИТЫ (кастодиальная модель)
-- ==========================================================
CREATE TABLE wallets (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    currency       TEXT NOT NULL,           -- 'USDT_TRC20' | 'BTC' | 'TRX' ...
    deposit_address TEXT NOT NULL,          -- уникальный адрес для приёма, либо общий адрес + memo

    -- available_balance: то, что пользователь реально может вывести
    -- held_balance: то, что "заморожено" — видно, но недоступно для вывода
    available_balance NUMERIC(24,8) NOT NULL DEFAULT 0,
    held_balance       NUMERIC(24,8) NOT NULL DEFAULT 0,

    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id, currency)
);

-- Входящие блокчейн-транзакции на депозитные адреса
CREATE TABLE deposits (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_id       UUID NOT NULL REFERENCES wallets(id),
    tx_hash         TEXT NOT NULL,
    amount_gross    NUMERIC(24,8) NOT NULL,   -- сколько реально пришло on-chain
    network_fee     NUMERIC(24,8) NOT NULL DEFAULT 0,
    margin_fee      NUMERIC(24,8) NOT NULL DEFAULT 0, -- буфер на комиссию (см. сервис deposit-margin)
    amount_credited NUMERIC(24,8) NOT NULL,   -- сколько зачислено на баланс = gross - margin_fee
    confirmations   INTEGER NOT NULL DEFAULT 0,
    status          TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','confirmed','credited')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(tx_hash)
);

CREATE TABLE withdrawals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_id       UUID NOT NULL REFERENCES wallets(id),
    to_address      TEXT NOT NULL,
    amount          NUMERIC(24,8) NOT NULL,
    network_fee     NUMERIC(24,8) NOT NULL DEFAULT 0,
    tx_hash         TEXT,
    status          TEXT NOT NULL DEFAULT 'requested'
                     CHECK (status IN ('requested','processing','sent','failed')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    processed_at    TIMESTAMPTZ
);


-- ==========================================================
-- СДЕЛКИ / ЭСКРОУ
-- ==========================================================
CREATE TABLE deals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    listing_id      UUID NOT NULL REFERENCES listings(id),
    buyer_id        UUID NOT NULL REFERENCES users(id),
    seller_id       UUID NOT NULL REFERENCES users(id),

    price_usd       NUMERIC(12,2) NOT NULL,      -- зафиксированная цена сделки на момент покупки
    currency        TEXT NOT NULL,                -- в чём фактически оплачено
    amount_paid     NUMERIC(24,8) NOT NULL,       -- сумма в этой валюте

    -- жизненный цикл сделки
    status          TEXT NOT NULL DEFAULT 'awaiting_payment'
                     CHECK (status IN (
                        'awaiting_payment',   -- ждём поступления оплаты
                        'held',               -- оплата получена и заморожена (held_balance продавца/эскроу)
                        'delivered',          -- продавец отметил "передал товар"
                        'confirmed',          -- покупатель подтвердил — деньги освобождены продавцу
                        'disputed',           -- открыт спор
                        'refunded',           -- возврат покупателю
                        'cancelled'
                     )),

    delivered_at     TIMESTAMPTZ,
    confirm_deadline  TIMESTAMPTZ,          -- авто-подтверждение, если покупатель молчит N дней
    confirmed_at      TIMESTAMPTZ,

    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_deals_buyer  ON deals(buyer_id);
CREATE INDEX idx_deals_seller ON deals(seller_id);
CREATE INDEX idx_deals_status ON deals(status);

-- Перед оплатой конкретной сделки покупатель подтверждает email кодом (purpose='confirm_purchase')
CREATE TABLE purchase_intents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id         UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    email_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE disputes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id         UUID NOT NULL REFERENCES deals(id),
    opened_by       UUID NOT NULL REFERENCES users(id),
    reason          TEXT NOT NULL,
    resolution       TEXT,
    resolved_by      UUID REFERENCES users(id),   -- модератор
    status           TEXT NOT NULL DEFAULT 'open'
                      CHECK (status IN ('open','resolved_buyer','resolved_seller','closed')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at        TIMESTAMPTZ
);


-- ==========================================================
-- ЧАТ СДЕЛКИ (переписка между покупателем/продавцом)
-- ==========================================================
CREATE TABLE deal_messages (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id      UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
    sender_id    UUID NOT NULL REFERENCES users(id),
    body_encrypted TEXT NOT NULL,     -- шифруется на уровне приложения (см. crypto-service)
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_deal_messages_deal ON deal_messages(deal_id, created_at);


-- ==========================================================
-- ОТЗЫВЫ (модель как в FunPay — привязаны к конкретной сделке)
-- ==========================================================
CREATE TABLE reviews (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id      UUID NOT NULL UNIQUE REFERENCES deals(id), -- один отзыв на сделку
    author_id    UUID NOT NULL REFERENCES users(id),         -- всегда покупатель
    target_id    UUID NOT NULL REFERENCES users(id),         -- всегда продавец
    rating       SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment      TEXT,
    seller_reply TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_target ON reviews(target_id);

-- Пересчёт рейтинга продавца при добавлении отзыва
CREATE OR REPLACE FUNCTION recalc_user_rating() RETURNS TRIGGER AS $$
BEGIN
    UPDATE users u SET
        rating_avg = sub.avg_rating,
        rating_count = sub.cnt
    FROM (
        SELECT target_id, ROUND(AVG(rating)::numeric, 2) AS avg_rating, COUNT(*) AS cnt
        FROM reviews WHERE target_id = NEW.target_id
        GROUP BY target_id
    ) sub
    WHERE u.id = sub.target_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_recalc_rating
AFTER INSERT ON reviews
FOR EACH ROW EXECUTE FUNCTION recalc_user_rating();


-- ==========================================================
-- КУРСЫ ВАЛЮТ (кэш котировок для конвертера)
-- ==========================================================
CREATE TABLE exchange_rates (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    base        TEXT NOT NULL,        -- 'USD'
    quote       TEXT NOT NULL,        -- 'AMD' | 'RUB' | 'USDT' | 'BTC' | 'TRX'
    rate        NUMERIC(24,8) NOT NULL,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(base, quote)
);


-- ==========================================================
-- АУДИТ-ЛОГ (для государственных проверок / внутреннего разбора споров)
-- Отдельная append-only таблица, доступ только у системы, не у пользователей
-- ==========================================================
CREATE TABLE audit_log (
    id           BIGSERIAL PRIMARY KEY,
    actor_id     UUID REFERENCES users(id),       -- кто совершил действие (может быть NULL для системных)
    actor_role   TEXT NOT NULL DEFAULT 'user',      -- 'user' | 'system' | 'admin'
    action        TEXT NOT NULL,                     -- 'deal.paid' | 'deal.confirmed' | 'withdrawal.sent' ...
    entity_type   TEXT NOT NULL,                     -- 'deal' | 'wallet' | 'user' ...
    entity_id     UUID,
    metadata      JSONB,
    ip_address    INET,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_actor  ON audit_log(actor_id);

-- audit_log никогда не редактируется и не удаляется приложением —
-- права на UPDATE/DELETE этой таблице роли приложения не выдаются (см. deploy notes).


-- ==========================================================
-- СЛУЖЕБНОЕ: чекпоинты фоновых воркеров (блокчейн-слушатель и т.п.)
-- ==========================================================
CREATE TABLE worker_checkpoints (
    worker_name   TEXT PRIMARY KEY,
    checkpoint_ms BIGINT NOT NULL DEFAULT 0,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
